package com.example.flutter_racha_conta

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
